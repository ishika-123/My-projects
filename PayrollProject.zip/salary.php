<HTML>
<HEAD>
<TITLE>SALARY </TITLE>
</HEAD>
<BODY background="salary4.jpg">
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp




&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp



<form name="form3" method="post" action="submitsal.php"/>
<CENTER>

<font color="white" size=50 face="Times New Roman">&nbsp;&nbsp;&nbsp; SALARY DETAILS OF EMPLOYEE</font>

<fieldset>
<TABLE >

<br><br><br><br><br>

<tr>

    <TD><B>EMPLOYEE NUMBER:</B></TD>
    <td><INPUT TYPE="text" NAME="emp_no" size =25 autofocus></td>

</tr>


<tr>

  <TD><B>BASIC SALARY :</B></TD>
  <TD><INPUT TYPE="text" NAME="basic_sal" size=25 autofocus></TD>

</tr>



<tr>

    <TD><B>DA :</B></TD>
    <TD><INPUT TYPE="text" NAME="DA" size=25 autofocus></TD>

</tr>

<tr>
    <TD><B>HRA :</B></TD>
    <TD><INPUT TYPE="text" NAME="HRA" size=25 autofocus></TD>

    

</tr>

<tr>
    <TD><B>BUS FEE :</B></TD>
    <TD><INPUT TYPE="text" NAME="bus" size=25 autofocus></TD>
</tr>

<tr>
   <TD><B>SECURITY :</b></TD>
   <TD><INPUT TYPE="tel" NAME="security" size=25  autofocus></TD>

</tr>

<tr>

   <td><b>TAX :</b></td>
   <td><INPUT type="text" name="tax" size=25 autofocus></td>

</tr>



<tr><td><b><button type="submit">Submit</button></b></td></tr>


</form>

</center>
</body>

</html>
