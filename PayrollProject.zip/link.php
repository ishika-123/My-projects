<html>
<style>
.rectangle
{
	background-color: white;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  opacity: 0.8;
  position: fixed;
  bottom: 700px;
  right: 800px;
  width: 200px;
}
.rectangle1
{
	background-color: white;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  opacity: 0.8;
  position: fixed;
  bottom: 500px;
  right: 800px;
  width: 200px;
}
.rectangle2
{
	background-color: white;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  opacity: 0.8;
  position: fixed;
  bottom: 300px;
  right: 800px;
  width: 200px;
}
.rectangle3
{
	background-color: white;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  opacity: 0.8;
  position: fixed;
  bottom: 30px;
  right: 25px;
  width: 100px;
}

</style>
 <body background="bg.jpg" >
 
 <div class="rectangle2"><center><font color="white"><a href="gen.php">Generate payslip</a></center></font></div>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
 &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
<div class="rectangle"><center><a href="empl_regist.php">Add new employee</a></center></div>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
<div class="rectangle1"><center><a href="salary.php">Add salary deteils</a></center></div>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
 <div class="rectangle3">
<a href="home.php"><font color"white">Logout</font></a></div>
 
 </body>
 </html>